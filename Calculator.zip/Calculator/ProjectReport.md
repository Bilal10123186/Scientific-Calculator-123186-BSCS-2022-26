# Calculator App – Project Report

## 1. Introduction

This report details the design, development, and implementation of a native Android calculator application. The application provides standard arithmetic calculations, as well as scientific functions. It also includes a history feature to store and display previous calculations.

### Objectives

* To develop a fully functional calculator application for the Android platform.
* To provide a user-friendly interface for both basic and scientific calculations.
* To implement a history feature that allows users to view their previous calculations.
* To create a well-structured and maintainable codebase.

### Scope

The scope of this project is to create a calculator application that can perform the following:

*   **Basic Arithmetic:** Addition, subtraction, multiplication, and division.
*   **Scientific Functions:** Trigonometric functions (sin, cos, tan), logarithmic functions (log, ln), square root, and power functions.
*   **History:** A scrollable history of previous calculations.
*   **User Interface:** A clean and intuitive user interface with a toggleable scientific panel.

## 2. Literature Review

A review of existing calculator applications on the Google Play Store was conducted to understand the common features and design patterns. This analysis revealed that most calculators provide a clear and intuitive interface, with a strong emphasis on ease of use. The scientific calculator functionality is often hidden by default to avoid cluttering the interface for users who only need basic arithmetic operations. The history feature is also a common and highly requested feature, allowing users to recall previous calculations.

## 3. Methodology

The application is developed using the Java programming language and the native Android SDK. The development methodology is based on an iterative and incremental approach, with the application being built and tested in stages. The core logic of the calculator is encapsulated in a single `MainActivity.java` file, which handles all user input and calculations. The user interface is defined in XML layout files and is separated from the application logic to ensure a clean and maintainable codebase.

## 4. Project Planning and Design

### Tools and Technologies

*   **Android Studio:** The official Integrated Development Environment (IDE) for Android app development.
*   **Java:** The primary programming language used for the application logic.
*   **XML:** Used for designing the user interface layouts.
*   **Gradle:** The build system used for the project.

### Design

The user interface is designed to be clean and intuitive. The main screen of the application is divided into two main sections: the display and the buttons. The display shows the current expression and the result of the calculation. The buttons are used to input numbers and operators. A scientific panel is available and can be toggled by the user to reveal more advanced functions. The history of calculations is accessible via a drawer that slides in from the side of the screen.

## 5. Implementation

The implementation of the calculator is centered around the `MainActivity.java` file. This file contains the logic for handling user input, evaluating expressions, and updating the display. The following code snippet shows the `onClick` method, which is responsible for handling all button clicks:

```java
@Override
public void onClick(View v) {
    if (!(v instanceof MaterialButton)) return;
    
    MaterialButton button = (MaterialButton) v;
    String buttonText = button.getText().toString();

    int id = v.getId();
    if (id == R.id.btnAC) {
        expression = "";
        tvExpression.setText("");
        tvResult.setText("0");
        isNewOp = true;
    } else if (id == R.id.btnBack) {
        if (expression.length() > 0) {
            expression = expression.substring(0, expression.length() - 1);
            tvExpression.setText(expression);
        }
    } else if (id == R.id.btnEqual) {
        calculateResult();
    } else {
        if (isNewOp && !isOperator(buttonText)) {
            expression = "";
        }
        isNewOp = false;
        expression += buttonText;
        tvExpression.setText(expression);
    }
}
```

The core of the calculator's logic lies in the `evaluate` method, which is a recursive descent parser that evaluates the mathematical expression. This method is capable of handling a wide range of mathematical operations, including basic arithmetic, trigonometric functions, and more.

```java
public double evaluate(final String str) {
    return new Object() {
        int pos = -1, ch;

        void nextChar() {
            ch = (++pos < str.length()) ? str.charAt(pos) : -1;
        }

        boolean eat(int charToEat) {
            while (ch == ' ') nextChar();
            if (ch == charToEat) {
                nextChar();
                return true;
            }
            return false;
        }

        double parse() {
            nextChar();
            double x = parseExpression();
            if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
            return x;
        }

        double parseExpression() {
            double x = parseTerm();
            for (;;) {
                if      (eat('+')) x += parseTerm();
                else if (eat('−') || eat('-')) x -= parseTerm();
                else return x;
            }
        }

        double parseTerm() {
            double x = parseFactor();
            for (;;) {
                if      (eat('×') || eat('*')) x *= parseFactor();
                else if (eat('÷') || eat('/')) x /= parseFactor();
                else return x;
            }
        }

        double parseFactor() {
            if (eat('+')) return parseFactor();
            if (eat('−') || eat('-')) return -parseFactor();

            double x;
            int startPos = this.pos;
            if (eat('(')) {
                x = parseExpression();
                eat(')');
            } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                x = Double.parseDouble(str.substring(startPos, this.pos));
            } else if (ch >= 'a' && ch <= 'z' || ch == '√' || ch == 'π') {
                while (ch >= 'a' && ch <= 'z' || ch == '√' || ch == 'π') nextChar();
                String func = str.substring(startPos, this.pos);
                if (func.equals("π")) x = Math.PI;
                else if (func.equals("e")) x = Math.E;
                else {
                    x = parseFactor();
                    if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else if (func.equals("asin")) x = Math.toDegrees(Math.asin(x));
                    else if (func.equals("acos")) x = Math.toDegrees(Math.acos(x));
                    else if (func.equals("atan")) x = Math.toDegrees(Math.atan(x));
                    else if (func.equals("log")) x = Math.log10(x);
                    else if (func.equals("ln")) x = Math.log(x);
                    else if (func.equals("√")) x = Math.sqrt(x);
                    else throw new RuntimeException("Unknown function: " + func);
                }
            } else {
                throw new RuntimeException("Unexpected: " + (char)ch);
            }

            if (eat('^')) x = Math.pow(x, parseFactor());

            return x;
        }
    }.parse();
}
```

## 6. Results and Discussion

The final application is a fully functional calculator that meets all of the project objectives. The application is easy to use and provides a wide range of functionality. The use of a recursive descent parser for expression evaluation is a key feature of the application, and it has proven to be a robust and reliable solution. The history feature is also a valuable addition, as it allows users to easily review their previous calculations.

## 7. Conclusion

This project has been a success, and the final application is a testament to the power and flexibility of the native Android platform. The application is well-structured, maintainable, and easy to use. The development process has provided valuable experience in Android app development, and the final product is a useful and practical application.

## 8. Recommendations

Future improvements to the application could include:

*   **Themes:** Allow the user to customize the look and feel of the calculator.
*   **Currency Conversion:** Add a feature to convert between different currencies.
*   **Unit Conversion:** Add a feature to convert between different units of measurement.

## 9. References

*   Android Developer Documentation: [https://developer.android.com/](https://developer.android.com/)

## 10. Appendices

*   **Source Code:** The complete source code for the application is available in the project files.
