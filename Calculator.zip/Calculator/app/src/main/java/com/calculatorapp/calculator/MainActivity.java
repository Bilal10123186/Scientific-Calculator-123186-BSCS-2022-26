package com.calculatorapp.calculator;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.button.MaterialButton;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tvExpression, tvResult;
    private String expression = "";
    private boolean isNewOp = true;
    private double memory = 0;
    
    // History components
    private DrawerLayout drawerLayout;
    private LinearLayout historyLayout;
    private List<String> historyList = new ArrayList<>();
    
    // Scientific Panel
    private TableLayout scientificPanel;
    private MaterialButton btnToggleSci;
    private boolean isSciVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvExpression = findViewById(R.id.tvExpression);
        tvResult = findViewById(R.id.tvResult);
        drawerLayout = findViewById(R.id.drawerLayout);
        historyLayout = findViewById(R.id.historyLayout);
        scientificPanel = findViewById(R.id.scientificPanel);
        btnToggleSci = findViewById(R.id.btnToggleSci);
        
        View btnHistory = findViewById(R.id.btnHistory);
        if (btnHistory != null) {
            btnHistory.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.END));
        }

        if (btnToggleSci != null) {
            btnToggleSci.setOnClickListener(v -> toggleScientificMode());
        }

        MaterialButton btnClearHistory = findViewById(R.id.btnClearHistory);
        if (btnClearHistory != null) {
            btnClearHistory.setOnClickListener(v -> {
                historyList.clear();
                historyLayout.removeAllViews();
            });
        }

        setClickListeners();
    }

    private void toggleScientificMode() {
        isSciVisible = !isSciVisible;
        if (scientificPanel != null) {
            scientificPanel.setVisibility(isSciVisible ? View.VISIBLE : View.GONE);
            btnToggleSci.setText(isSciVisible ? "Basic Mode" : "Scientific Mode");
            btnToggleSci.setIconResource(isSciVisible ? android.R.drawable.arrow_up_float : android.R.drawable.arrow_down_float);
        }
    }

    private void setClickListeners() {
        int[] ids = {
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9,
            R.id.btnDot, R.id.btnAdd, R.id.btnMinus, R.id.btnMultiply,
            R.id.btnDivide, R.id.btnEqual, R.id.btnAC, R.id.btnBack,
            R.id.btnSin, R.id.btnCos, R.id.btnTan, R.id.btnLog,
            R.id.btnLn, R.id.btnSqrt, R.id.btnPi, R.id.btnPower,
            R.id.btnOpenBracket, R.id.btnCloseBracket,
            R.id.btnAsin, R.id.btnAcos, R.id.btnAtan, R.id.btnE,
            R.id.btnMC, R.id.btnMR, R.id.btnMPlus, R.id.btnMMinus, R.id.btnMS
        };

        for (int id : ids) {
            View v = findViewById(id);
            if (v != null) {
                v.setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (!(v instanceof MaterialButton)) return;
        
        MaterialButton button = (MaterialButton) v;
        String buttonText = button.getText().toString();

        int id = v.getId();
        if (id == R.id.btnAC) {
            expression = "";
            tvExpression.setText("");
            tvResult.setText("0");
            isNewOp = true;
        } else if (id == R.id.btnBack) {
            if (expression.length() > 0) {
                expression = expression.substring(0, expression.length() - 1);
                tvExpression.setText(expression);
            }
        } else if (id == R.id.btnEqual) {
            calculateResult();
        } else if (id == R.id.btnPi) {
            expression += "π";
            tvExpression.setText(expression);
            isNewOp = false;
        } else if (id == R.id.btnE) {
            expression += "e";
            tvExpression.setText(expression);
            isNewOp = false;
        } else if (id == R.id.btnSin || id == R.id.btnCos || id == R.id.btnTan || 
                   id == R.id.btnLog || id == R.id.btnLn || id == R.id.btnSqrt ||
                   id == R.id.btnAsin || id == R.id.btnAcos || id == R.id.btnAtan) {
            expression += buttonText + "(";
            tvExpression.setText(expression);
            isNewOp = false;
        } else if (id == R.id.btnMC) {
            memory = 0;
        } else if (id == R.id.btnMR) {
            expression += formatResult(memory);
            tvExpression.setText(expression);
        } else if (id == R.id.btnMPlus) {
            calculateResult();
            memory += Double.parseDouble(tvResult.getText().toString());
        } else if (id == R.id.btnMMinus) {
            calculateResult();
            memory -= Double.parseDouble(tvResult.getText().toString());
        } else if (id == R.id.btnMS) {
            calculateResult();
            memory = Double.parseDouble(tvResult.getText().toString());
        } else {
            if (isNewOp && !isOperator(buttonText)) {
                expression = "";
            }
            isNewOp = false;
            expression += buttonText;
            tvExpression.setText(expression);
        }
    }

    private boolean isOperator(String s) {
        return s.equals("+") || s.equals("−") || s.equals("×") || s.equals("÷") || s.equals("^");
    }

    private void calculateResult() {
        if (expression.isEmpty()) return;
        try {
            double result = evaluate(expression);
            String formattedResult = formatResult(result);
            
            // Add to history
            addToHistory(expression + " = " + formattedResult);
            
            tvResult.setText(formattedResult);
            isNewOp = true;
        } catch (Exception e) {
            tvResult.setText("Error");
        }
    }

    private void addToHistory(String entry) {
        historyList.add(0, entry);
        
        View historyItem = LayoutInflater.from(this).inflate(android.R.layout.simple_list_item_1, null);
        TextView tv = historyItem.findViewById(android.R.id.text1);
        tv.setText(entry);
        tv.setTextColor(getResources().getColor(R.color.text_primary));
        tv.setPadding(0, 20, 0, 20);
        
        historyLayout.addView(historyItem, 0);
        
        // Limit history to 20 items
        if (historyLayout.getChildCount() > 20) {
            historyLayout.removeViewAt(20);
        }
    }

    private String formatResult(double result) {
        if (Double.isInfinite(result) || Double.isNaN(result)) return "Error";
        if (result == (long) result) {
            return String.format("%d", (long) result);
        } else {
            return new DecimalFormat("#.##########").format(result);
        }
    }

    public double evaluate(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if      (eat('+')) x += parseTerm();
                    else if (eat('−') || eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if      (eat('×') || eat('*')) x *= parseFactor();
                    else if (eat('÷') || eat('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('−') || eat('-')) return -parseFactor();

                double x;
                int startPos = this.pos;
                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z' || ch == '√' || ch == 'π') {
                    while (ch >= 'a' && ch <= 'z' || ch == '√' || ch == 'π') nextChar();
                    String func = str.substring(startPos, this.pos);
                    if (func.equals("π")) x = Math.PI;
                    else if (func.equals("e")) x = Math.E;
                    else {
                        x = parseFactor();
                        if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                        else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                        else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                        else if (func.equals("asin")) x = Math.toDegrees(Math.asin(x));
                        else if (func.equals("acos")) x = Math.toDegrees(Math.acos(x));
                        else if (func.equals("atan")) x = Math.toDegrees(Math.atan(x));
                        else if (func.equals("log")) x = Math.log10(x);
                        else if (func.equals("ln")) x = Math.log(x);
                        else if (func.equals("√")) x = Math.sqrt(x);
                        else throw new RuntimeException("Unknown function: " + func);
                    }
                } else {
                    throw new RuntimeException("Unexpected: " + (char)ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor());

                return x;
            }
        }.parse();
    }
}
